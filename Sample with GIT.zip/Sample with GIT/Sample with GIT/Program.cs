﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Sample_with_GIT
{
    class Program
    {
        #region Properties
        private bool _taskIsRunning = false;
        private delegate void FileDelegate(string a);
        private readonly object _sync = new object();
        public event AsyncCompletedEventHandler taskCompleted;

        public bool testIsRunning
        {
            get { return _taskIsRunning; }
        }
        #endregion

        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.UpdateFileAsync("Hello Welcome..");
            Console.ReadKey();
        }

        public async Task UpdateFileAsync(string str)
        {
            FileDelegate fileDelegate = new FileDelegate(UpdateTextFile);
            AsyncCallback completedCallback = new AsyncCallback(TaskCallback);
            lock (_sync)
            {
                if (_taskIsRunning)
                    Console.WriteLine("task is running..");

                AsyncOperation async = AsyncOperationManager.CreateOperation(null);
                fileDelegate.BeginInvoke(str, completedCallback, async);
                _taskIsRunning = true;
            }
        }
        public void UpdateTextFile(string str)
        {
            string path = Directory.GetCurrentDirectory() + "\\test.txt";
            // This text is added only once to the file.
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine(str);
                }
            }

            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine("This request is made on: " + DateTime.Now.ToString());
            }
        }
        private void TaskCallback(IAsyncResult ar)
        {
            try
            {
                // get the original worker delegate and the AsyncOperation instance
                FileDelegate fileDelegate = (FileDelegate)((AsyncResult)ar).AsyncDelegate;
                AsyncOperation async = (AsyncOperation)ar.AsyncState;

                // finish the asynchronous operation
                fileDelegate.EndInvoke(ar);

                // clear the running task flag
                lock (_sync)
                {
                    _taskIsRunning = false;
                }

                // raise the completed event
                AsyncCompletedEventArgs completedArgs = new AsyncCompletedEventArgs(null, false, null);

                async.PostOperationCompleted(
                    delegate (object e) { OnTaskCompleted((AsyncCompletedEventArgs)e); },
                    completedArgs);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected virtual void OnTaskCompleted(AsyncCompletedEventArgs e)
        {
            if (taskCompleted != null)
                taskCompleted(this, e);
        }

        public async Task Method2(long a, long b)
        {
            await Task.Run(() =>
            {
                Console.WriteLine(" Method2 is calling");
            });
        }
    }
}
